#!/bin/sh
set -e

echo "=================================================="
echo "  开始安装 v2rayA + v2ray-core 独立离线安装包"
echo "  适用设备: Newifi 3 (D2) / MT7621 (OpenWrt 25.12+)"
echo "=================================================="

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo ">>> [1/4] 安装离线软件包 (apk)..."
apk add --allow-untrusted \
    v2ray-core-5.53.0-r1.apk \
    v2raya-2.2.7.5-r2.apk \
    v2ray-geoip-202610050438-r1.apk \
    v2ray-geosite-20261009101206-r1.apk \
    luci-app-v2raya-26.288.56989~75a306d.apk \
    luci-i18n-v2raya-zh-cn-26.288.56989~75a306d.apk

echo ">>> [2/4] 配置 v2rayA 绑定官方原生 v2ray-core 内核..."
uci set v2raya.config.enabled='1'
uci set v2raya.config.v2ray_bin='/usr/bin/v2ray'
uci commit v2raya

echo ">>> [3/4] 启动并开机自启 v2rayA..."
/etc/init.d/v2raya enable
/etc/init.d/v2raya restart

echo ">>> [4/4] 检查服务状态..."
sleep 2
if ps -w | grep -v grep | grep -q "v2raya"; then
    echo "=================================================="
    echo "  SUCCESS! v2rayA + v2ray-core 安装配置成功！"
    echo "  Web 管理地址: http://192.168.1.1:2017"
    echo "  LuCI 后台菜单: 服务 -> v2rayA"
    echo "  当前调用核心: /usr/bin/v2ray (原生支持 allowInsecure)"
    echo "=================================================="
else
    echo "ERROR: v2rayA 未能正常启动，请执行 logread 查看日志。"
    exit 1
fi
