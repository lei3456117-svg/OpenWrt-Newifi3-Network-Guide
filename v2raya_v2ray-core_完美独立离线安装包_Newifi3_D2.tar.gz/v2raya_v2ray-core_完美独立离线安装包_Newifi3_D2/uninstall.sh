#!/bin/sh
echo "=== 卸载 v2ray-core 与 v2rayA ==="
/etc/init.d/v2raya stop 2>/dev/null || true
/etc/init.d/v2raya disable 2>/dev/null || true
apk del luci-i18n-v2raya-zh-cn luci-app-v2raya v2raya v2ray-core v2ray-geoip v2ray-geosite 2>/dev/null || true
uci delete v2raya 2>/dev/null || true
uci commit v2raya 2>/dev/null || true
echo "已完成卸载。"
